CREATE TABLE alunos (
    id INT PRIMARY KEY,
    nome VARCHAR(100),
    nota DECIMAL(4,2)
);
SELECT nome, nota FROM alunos WHERE nota > 7.0;

SELECT * FROM alunos